
<?php 
 session_start();
 ?>


<header>
        <div class="top-header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-3">
              <a href="#"><img src="img/logo.png" class="img-fluid logo" alt="" /></a> 
            </div>
            <div class="col-md-9">
              <!-- Start NavBar -->
              <nav class="navbar navbar-expand-lg navbar-light">
                <button
                  class="navbar-toggler"
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarNavDropdown"
                  aria-controls="navbarNavDropdown"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                  <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                      <a class="nav-link" href="#">Inicio</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Quienes Somos</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Aprende</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Ayuda</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Empresas</a>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </header>